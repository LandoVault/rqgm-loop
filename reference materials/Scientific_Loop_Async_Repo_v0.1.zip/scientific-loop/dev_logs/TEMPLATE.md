# <UTC timestamp> — <work item> — <agent>

Status: planned / implemented / locally verified / integrated / blocked.
Base commit:
Owned paths:
Objective and invariant IDs:
Changes made:
Commands executed and actual results:
Evidence/artifact hashes:
Resource usage and unknowns:
Decisions and deviations (ADR/amendment IDs):
Unimplemented or untested behavior:
Migration / rollback:
Next action and receiving owner:

Use a new file per session. Never report a design or simulation as a live scientific result.
