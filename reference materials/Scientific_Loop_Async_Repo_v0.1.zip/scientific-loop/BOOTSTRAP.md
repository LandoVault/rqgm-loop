# Starting the shared repository

The delivery ZIP contains this source directory plus `scientific-loop.bundle`, which preserves its initial Git commit and main branch. Choose one route:

```bash
# Preserve initial commit history:
git clone scientific-loop.bundle scientific-loop-repo
cd scientific-loop-repo
python -m unittest discover -s tests -v
python scripts/check_integrity.py
```

Or initialize the extracted source directory as a new Git repository. The bundle clone is preferred for consistent base-commit IDs across agents.

To attach a remote, replace the clone's bundle origin with the actual chosen URL:

```bash
git remote set-url origin <REMOTE_URL>
git push -u origin main
```

The URL is a placeholder, not an existing remote. Set access, branch protection and CI checks on that remote. No external invitations or publishing are required for local development.

Read `AGENTS.md` before creating worktrees. Assign W00 first; once contracts are pinned, W01 and W02 can run independently. Source integration is serialized through the integrator; scientific workers later run asynchronously through the runtime coordinator.
