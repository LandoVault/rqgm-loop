"""Contract reference only; not a distributed runtime."""
