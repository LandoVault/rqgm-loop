"""Single-process contract reference. No persistence, network or scientific oracle.

Caller supplies trusted verdicts; production must authenticate and digest-bind them.
The caller's clock is explicit for deterministic tests; production uses server time.
"""
from dataclasses import dataclass, asdict
from copy import deepcopy
import hashlib
import json


class Rejected(ValueError):
    pass


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                    allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class Lease:
    owner: str
    generation: int
    expires_at: int


@dataclass(frozen=True)
class Patch:
    result_id: str
    task_id: str
    owner: str
    generation: int
    epoch: int
    reads: dict  # entity -> exact version; 0 means absent
    expected_writes: dict  # entity -> exact version
    writes: dict  # entity -> new JSON payload


class Kernel:
    """Point-read/write acceptance only. Not a complete state machine."""
    def __init__(self):
        self.epoch = 1
        self.entities = {}  # entity -> (version, payload)
        self.leases = {}
        self.generations = {}
        self.required_gates = {}
        self.receipts = {}  # result ID -> (digest, receipt)
        self.completed = set()

    def lease(self, task, owner, now, ttl, required_gates):
        if ttl <= 0 or not required_gates or task in self.completed:
            raise Rejected('INVALID_LEASE')
        old = self.leases.get(task)
        if old and now < old.expires_at:
            raise Rejected('ALREADY_LEASED')
        if task in self.required_gates and self.required_gates[task] != frozenset(required_gates):
            raise Rejected('GATE_CONTRACT_CHANGED')
        generation = self.generations.get(task, 0) + 1
        lease = Lease(owner, generation, now + ttl)
        self.generations[task] = generation
        self.leases[task] = lease
        self.required_gates[task] = frozenset(required_gates)
        return lease

    def commit(self, patch, verdicts, now):
        payload_digest = digest(asdict(patch))
        if patch.result_id in self.receipts:
            old_digest, receipt = self.receipts[patch.result_id]
            if old_digest != payload_digest:
                raise Rejected('IDENTITY_CONFLICT')
            return deepcopy(receipt)  # replay of historical receipt, not new acceptance
        if patch.task_id in self.completed:
            raise Rejected('TASK_COMPLETED')
        lease = self.leases.get(patch.task_id)
        if lease is None or (lease.owner, lease.generation) != (patch.owner, patch.generation):
            raise Rejected('FENCED')
        if now >= lease.expires_at:
            raise Rejected('EXPIRED')
        if patch.epoch != self.epoch:
            raise Rejected('EPOCH_CHANGED')
        required = self.required_gates[patch.task_id]
        if any(verdicts.get(g) != 'PASS' for g in required):
            raise Rejected('GATE_FAILED')
        if not patch.writes or set(patch.writes) != set(patch.expected_writes):
            raise Rejected('WRITE_SET_MISMATCH')
        for guard in (patch.reads, patch.expected_writes):
            for entity, version in guard.items():
                if type(version) is not int or version < 0:
                    raise Rejected('INVALID_VERSION')
                if self.entities.get(entity, (0, None))[0] != version:
                    raise Rejected('STALE')
        # Stage all updates before mutating the reference state.
        staged = deepcopy(self.entities)
        for entity, value in patch.writes.items():
            staged[entity] = (patch.expected_writes[entity] + 1, deepcopy(value))
        receipt = {'result_id': patch.result_id, 'digest': payload_digest,
                   'versions': {key: staged[key][0] for key in patch.writes},
                   'epoch': self.epoch}
        self.entities = staged
        self.completed.add(patch.task_id)
        self.receipts[patch.result_id] = (payload_digest, deepcopy(receipt))
        return receipt


class TokenLedger:
    """Reference single-resource reservation ledger; not crash/concurrency safe."""
    def __init__(self, cap):
        if type(cap) is not int or cap < 0:
            raise ValueError('invalid cap')
        self.cap = cap
        self.spent = 0
        self.pending = {}
        self.settled = {}
        self.halted = False

    def reserve(self, request_id, upper_bound):
        if type(upper_bound) is not int or upper_bound <= 0:
            raise Rejected('INVALID_RESERVATION')
        if request_id in self.pending:
            if self.pending[request_id] != upper_bound:
                raise Rejected('RESERVATION_CONFLICT')
            return
        if request_id in self.settled:
            raise Rejected('REQUEST_SETTLED')
        if self.halted or self.spent + sum(self.pending.values()) + upper_bound > self.cap:
            raise Rejected('BUDGET_DENIED')
        self.pending[request_id] = upper_bound

    def settle(self, request_id, actual):
        if request_id in self.settled:
            if self.settled[request_id] != actual:
                raise Rejected('USAGE_CONFLICT')
            return
        if request_id not in self.pending:
            raise Rejected('UNKNOWN_REQUEST')
        if actual is None:
            return  # retain reservation until reconciliation
        if type(actual) is not int or actual < 0:
            raise Rejected('INVALID_USAGE')
        upper = self.pending.pop(request_id)
        self.spent += actual
        self.settled[request_id] = actual
        if actual > upper:
            # Keep real usage, fail closed for new calls; never hide overspend.
            self.halted = True
            raise Rejected('PROVIDER_BOUND_BREACH')
