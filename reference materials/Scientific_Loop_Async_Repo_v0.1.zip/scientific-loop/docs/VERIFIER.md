# Verification specification

## Levels and scope

| Level | What passes | What it does not establish |
|---|---|---|
| V0 Contract | Required fields, identities, hashes, versions and budgets | Scientific correctness |
| V1 Execution | Reproducible tool invocation and expected output format | A true scientific claim |
| V2 Scientific obligation | Domain-specific numerical, symbolic or empirical acceptance gate | Universal theorem unless the gate proves it |
| V3 Formal | Pinned proof checker accepts stated theorem and trusted base | Statement fidelity or empirical truth of premises |
| V4 Study | Independent scoring under a frozen study manifest | Generalization beyond measured task/model scope |

Every gate returns PASS, FAIL, UNKNOWN or ERROR. Only PASS satisfies an obligation. A timeout is ERROR, missing evidence is UNKNOWN; neither is a negative scientific result by itself. Verified completion requires all mandatory gates. Partial verified obligations remain separately reportable.

## Attestation

Required: candidate_digest, verifier_id, verifier_version, verifier_code_hash, epoch, environment_hash, input hashes, obligation IDs and verdicts, execution command, tool versions, stdout/stderr artifact hashes, elapsed/CPU time, limitations, and attesting principal. The commit service verifies the attestation came from an authorized verifier and binds exactly to the candidate. Worker-supplied `passed: true` is not an attestation.

Formal and numeric verifiers run in isolated environments with time/memory ceilings. A candidate cannot change hidden tests or expected values. Where independence is limited by shared code or model family, record it; an extra model vote is not a replacement for a scientific oracle.

## Yang–Mills adapter

The imported `run_checks.py` has two supplied coefficient-search loops and six additional symbolic check groups. Preserve it byte-for-byte. Run it in an isolated copy:

```bash
mkdir -p runs/ym-replay-001
cp fixtures/yang_mills/run_checks.py runs/ym-replay-001/
python runs/ym-replay-001/run_checks.py
```

Use `sympy==1.14.0`; record the exact Python/runtime version. Assertions must remain enabled; do not use Python `-O`. Adapter checks process exit, output schema, six actual candidate records matching expected accept/reject outcomes, and all six additional group results. Do not accept a hand-edited summary count without records.

Limitations: fixture-specific covariance checks are not universal formal proofs; the action integration-by-parts argument is written in the report but not machine proved. No Lean proof, sourced matter equation, full quantization section, mass discussion, autonomous discovery or 3D spacetime simulation is implemented. The paper was known/consulted, so reconstruction is contaminated as a discovery benchmark.

Report separately: (a) check pass fraction, (b) correctness of candidate classification, (c) fraction of independent fresh runs meeting all prespecified gates, and (d) mapped paper obligations completed. Only (c), with denominator, environment and repeat policy, supports a reproducibility estimate; (d) needs a frozen obligation map. One run cannot supply a robust reproducibility estimate.

## Oscillator adapter target

Assumptions and damping regimes as in frozen protocol. Compare initial conditions, equation residuals and independent integration. Include undamped resonance and critical-damping singular limits; distinguish solution-domain errors from floating-point instability. Pin scales, grids, tolerances and oracle before study execution. No oscillator implementation is included yet.

## NUFFT adapter target

Type-1 1D: `f_k = sum_j c_j exp(-i*k*x_j)`; explicitly record periodic positions, centered mode order and no normalization. Direct complex summation is the small-case oracle. Test every mode, complex strengths, clustered/coincident/boundary/uniform positions and cancellation. Report relative L2 and error scaled by sum of absolute strengths with explicit zero-input handling. A numeric pass is not a proved global error bound. Type-3 and inverse problems require separate contracts. No NUFFT implementation is included yet.

## Lean adapter target

Resolve the intended First Derivation Lab first. Pin commit, license, toolchain and dependencies. Record statement-to-source mapping, compilation output, theorem dependencies, introduced axioms, and `sorry`/`admit` audit. Never equate a text sketch with a compiled proof. Allow normal logical axioms only as declared trusted base. Lean integration remains unimplemented.

## Verification economy

Use cheap contract and cache checks first, then obligation-specific tools, then selected intervention or independent replication. Record all costs including rejected candidates. Sensitivity screening may prioritize numerical tests when assumptions justify it; it never substitutes for acceptance gates. A stale certificate may require only local revalidation, but dependent claims remain unavailable until that is complete.
