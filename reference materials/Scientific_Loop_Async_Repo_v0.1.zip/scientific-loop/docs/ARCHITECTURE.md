# Architecture and boundaries

## Objective

Produce more independently verified scientific work per budget while retaining a recoverable account of claims, assumptions, revisions, and resources. This is a proposed design, not a new theorem or a demonstrated optimal scheduler.

## Components

```mermaid
flowchart TD
    Events["Evidence and task events"] --> Scheduler["Budgeted scheduler"]
    Scheduler --> Workers["Bounded worker pool"]
    Workers --> Proposals["Candidate updates"]
    Proposals --> Verifier["Verification service"]
    Verifier --> Commit["Transactional commit"]
    Commit --> State["Versioned scientific state"]
    State --> Scheduler
    Workers --> Retrieval["Resource discovery"]
    Retrieval --> Proposals
    Commit --> Audit["Immutable event archive"]
```

Workers never directly write accepted scientific state. Verifiers attest to explicit obligations; a commit service checks the snapshot and attestation again in a transaction. Verification outside the transaction may take minutes, so a passed verdict alone never bypasses stale-read checks.

| Component | Owns | Does not own |
|---|---|---|
| Scientific state | Claims, assumptions, evidence lineage, typed links, unresolved questions | Global transcript as truth |
| Scheduler | Ready-set selection, quotas, reservations, deadlines, fairness | Scientific validity |
| Worker adapter | Model/tool execution on an explicit capsule | Canonical-state mutation |
| Verifier service | Versioned gates and machine-readable verdicts | Candidate generation policy |
| Commit service | Atomic admissible updates and event append | Majority-vote truth |
| Artifact store | Immutable content by hash, retention and access control | Unversioned mutable outputs |
| Meta-Evaluator | Proposed scorer/policy improvements evaluated on held-out tasks | Silent in-epoch rule changes |

## State model

`S = (entities, typed_relations, evidence, assumption_environments, tasks, judgments, epochs, budgets, events)`.

Entity types: Claim, Assumption, Equation, Definition, Observation, Resource, OpenQuestion, Hypothesis, Operation, VerificationRecord, Decision. Give every entity a stable ID and every revision an immutable content hash. Keep payload versions separate from validation status.

Relations include `depends_on`, `supports`, `contradicts`, `analogous_to`, `derived_from`, and `same_observation_lineage`. An implication records its assumptions and proof obligation. Similarity is never automatically promoted to implication. A conceptual graph may contain cycles; executable acyclic dependencies or explicit strongly connected solver groups control actual work.

Assumption environments label branches. Contradictory environments may coexist. A claim can be verified conditional on environment E without becoming universally accepted. For a probabilistic update, store likelihood, prior provenance, conditioning set, observation lineage and model version; otherwise use qualitative support with uncertainty. Do not create Bayesian certainty from an agent's confidence score.

## Incremental revision

Maintain reverse dependencies. On change, mark affected claims pending revalidation and block publication of their current certificates. Recompute required ancestors before a consumer commits. Compare both semantic payload and certificate validity: unchanged numerical output cannot retain a proof whose premises were withdrawn. Unaffected branches stay usable. A large dependency cone can still require global work.

Cache keys include inputs, assumptions, code, toolchain, randomness, precision and relevant verifier contract. Cache raw observations separately from judgments. No exact cache hit is inferred from embedding similarity. Fixpoint groups declare convergence metric, tolerance, iteration cap, and failure behavior; a nonconverged group is unresolved.

## Knowledge expansion

A knowledge gap can trigger RETRIEVE, REFRAME, or a request for missing data. The worker proposes queries and candidate concepts; these are not limited to a fixed bibliography. The runtime fixes access permissions, spending limits, and evidence requirements. Imported material gets identity, source location, timestamp, hash, provenance and applicability checks. New ontology or hypothesis proposals require migration/versioning, not untracked edits of existing terms.

## Four time scales

1. Local inference: derive/test/retrieve/branch on one problem.
2. Revision: reconcile new findings and invalidate affected certificates.
3. System improvement: develop better tools, prompts and scheduling policies on development tasks.
4. Evaluator evolution: replace a scorer at an explicit epoch boundary after independent validation.

Strategic Loop proposes useful questions and allocation; Development Loop produces candidate implementations. The Meta-Evaluator evaluates these proposals. None bypasses scientific verification or the user's fixed resource and protocol constraints. There is no requirement for four distinct LLM agents.

## Scale

Use a durable transaction store and blob store. Queue delivery is at least once. Store the task transition, budget reservation and outbox event in the same transaction. A separate dispatcher drains the outbox idempotently. Task claim uses compare-and-swap with a monotonically increasing fencing token. The server's lease clock is authoritative.

Start with one commit authority per run. Partition independent runs first. Within a run, lock affected IDs in stable order; cross-partition atomic writes require a real transaction or an explicit staged protocol. Do not promise lock-free or exactly-once execution. Global budget/epoch invariants remain coordinated. Measure contention before adding sharding.

A 200-worker configuration describes identities and subscription capacity; model concurrency is capped by budget, provider rate limits, independent ready work, and verifier throughput. No all-to-all chat channel is needed.
