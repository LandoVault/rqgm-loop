# State machines and commit semantics

## Task lifecycle

```mermaid
stateDiagram-v2
    [*] --> PENDING
    PENDING --> READY: prerequisites valid
    READY --> LEASED: atomic claim and reservation
    LEASED --> RUNNING: worker acknowledges
    RUNNING --> VERIFYING: immutable result submitted
    VERIFYING --> COMMITTED: all gates and versions valid
    VERIFYING --> STALE: dependency or epoch changed
    VERIFYING --> REJECTED: scientific gate fails
    RUNNING --> BLOCKED: missing knowledge or resource
    RUNNING --> READY: lease expires, retry allowed
    STALE --> READY: refreshed task capsule
    BLOCKED --> READY: prerequisite resolved
    REJECTED --> [*]
    COMMITTED --> [*]
```

Any nonterminal task can also enter CANCELLED or EXHAUSTED under recorded cancellation/budget policy. FAILED_TOOL is a recorded attempt outcome: retry creates a new attempt if permitted, otherwise task becomes EXHAUSTED. Attempts never disappear when the logical task re-enters READY.

| Transition | Guard | Atomic effects / event |
|---|---|---|
| PENDING → READY | Required payloads and certificates valid in environment | Update readiness; Ready event |
| READY → LEASED | No active lease, resources reserved, epoch active | Owner, generation++, expiry, attempt ID, reservation, outbox |
| LEASED → RUNNING | Owner and fencing generation match | Start timestamp |
| RUNNING → VERIFYING | Lease valid; result hash and read/write sets supplied | Persist candidate and usage; VerificationRequested |
| VERIFYING → COMMITTED | Verifier coverage, provenance, scope, epoch, versions, lease all pass | Writes + invalidations + event + idempotency receipt |
| VERIFYING → STALE | Any guarded input/certificate changed | Retain output, prohibit current acceptance, enqueue refresh if useful |
| VERIFYING → REJECTED | Valid verification of false candidate | Retain candidate and failure evidence; distinct repair/branch task may follow |
| RUNNING → BLOCKED | Explicit gap code and unresolved obligation | Suspend work, expose gap, optional bounded retrieval task |
| Lease timeout → READY | Expired generation; retry cap/budget permit | Fence old owner; account usage uncertainty; new attempt required |
| Any → EXHAUSTED | Budget or retry/time ceiling reached | Preserve partial valid output and unfulfilled obligations |

Verification may outlive a lease: the coordinator extends a verification lease under the same fencing discipline or marks the attempt stale. It must not accept a late result because it once had a lease.

## Claim and evidence lifecycle

Claim revision statuses: PROPOSED → CONDITIONALLY_VERIFIED or REJECTED; CONDITIONALLY_VERIFIED → STALE when a dependency/certificate changes; STALE → CONDITIONALLY_VERIFIED only with a new verification record. SUPERSEDED points to a new revision. Conditional verification records its domain and environment.

Observations are append-only. A correction adds a replacement/correction relation. A withdrawal changes admissibility, not historical bytes. A contradicted claim remains inspectable. Evidence with shared lineage is not counted as independent evidence.

## Knowledge-gap state

GAP_OPEN → QUERY_PROPOSED → RETRIEVING → CANDIDATE_RESOURCE → APPLICABILITY_CHECK → GAP_RESOLVED or GAP_UNRESOLVED. Negative search is logged with scope; it does not prove no relevant resource exists. REFRAME creates a new hypothesis/representation branch with a migration proposal. Repeated unproductive queries stop under the declared budget and retain the gap.

## Epoch lifecycle

ACTIVE → DRAINING → VALIDATING_SUCCESSOR → ACTIVE(new epoch) or ACTIVE(old epoch).

Stop issuing score-dependent tasks under the old epoch at DRAINING. Do not relabel in-flight judgments. A candidate can be retained as a raw artifact and reverified under the successor; old scores are excluded from current rankings. If only scoring changed, physical observations remain valid; if scientific verifier semantics changed, affected certificates require recertification. Log the precise affected set. Rollback creates another explicit epoch transition.

## Atomic commit transaction

1. Resolve a canonical result digest and idempotency key. Identical retries return the prior receipt; key reuse with a different digest is an error.
2. Lock run control, task, and relevant entity/certificate rows in a stable order.
3. Validate owner, generation, lease expiry, run status, epoch, and reserved-resource state.
4. Compare every read version and expected write version, including negative reads. Predicate/range queries carry a collection revision to detect newly inserted matching entities.
5. Verify attestation identity, candidate digest, gate coverage and artifact hashes; ensure environmental assumptions match.
6. Apply all writes and dependency invalidations; write acceptance receipt, event and outbox record in the same transaction.
7. Commit; publish notifications from the outbox. Crash after commit yields the same receipt on retry.

The artifact must exist and pass its checksum before a state record references it. Orphaned uploads can be garbage-collected after a retention window. Publishing notifications before durable commit is forbidden.

## Replay and rerun

Event replay reconstructs state using pinned reducers and recorded order. A fresh stochastic rerun asks a different empirical question and may differ. Tool side effects are recorded and never re-executed merely to reconstruct state. Unknown external-call completion goes to reconciliation; automatic retries need provider idempotency or explicit duplicate-execution accounting.
