# Architecture decision records

| ADR | Decision | Rationale | Revisit when |
|---|---|---|---|
| 001 | Event-driven on-demand role calls; durable explicit memory | Separate memory from process lifetime and avoid inference polling | Controlled lifecycle study reveals a useful difference |
| 002 | Transactional commit authority with optimistic dependency guards | Workers can explore independently while acceptance stays consistent | Measured cross-run/within-run contention |
| 003 | Typed scientific network plus execution dependencies | Share subresults and localize revision without confusing analogy with proof | Domain adapters expose unsupported relation semantics |
| 004 | Verifier separate from generator | Prevent self-declared success and enforce scientific scope | Different independent oracle becomes necessary |
| 005 | Preserve frozen studies and original fixture hashes | Avoid retroactive baseline/goal changes | A prospective amendment is accepted |
| 006 | Incremental reuse first; selective replay | Control recomputation without assuming all coupling is sparse | Measured cache/selection overhead outweighs reuse |
| 007 | Retrieval/reframe are first-class operations | Permit new evidence and hypotheses beyond initial knowledge | Capability policy changes |
| 008 | Small reference kernel, no pretend distributed MVP | Make key contracts executable while exposing unfinished infrastructure | W01–W03 pass durable fault suite |

These decisions are engineering defaults, not proven optimal or established research novelty.
