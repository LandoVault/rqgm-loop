# Invariants and enforcement map

Normative target contracts. The reference kernel implements only the subset indicated below; tests are not proof that a distributed deployment is safe.

| ID | Invariant | Enforcement / required negative test | Starter coverage |
|---|---|---|---|
| I01 | Accepted state changes only through commit authority | Worker write permissions denied | Design only |
| I02 | Every accepted claim names environment and evidence scope | Reject missing assumptions/provenance | Contract specification |
| I03 | No accepted stale reads or lost writes | Read + expected-write version CAS; include negative/predicate reads | Point-version reference |
| I04 | Expired owners cannot accept output | Monotone fencing token + server lease expiry | Reference generation/expiry checks |
| I05 | One result key identifies exactly one payload | Duplicate retry returns receipt; different payload rejected | Reference |
| I06 | Required verification covers exact candidate and contract | Digest-bound trusted attestation; missing/failing/unknown gate rejected | Gate IDs/status reference; trust integration pending |
| I07 | Observations and execution history are immutable | Corrections append; no destructive score replacement | Design only |
| I08 | Budgets include concurrent outstanding calls | Atomic reserve before dispatch; unknown usage retains reservation | In-memory reservation reference |
| I09 | Assumptions propagate to dependent certificates | Invalidate transitive dependencies; no reuse on similarity alone | Design only |
| I10 | Epoch changes never silently rebrand old judgments | Epoch check; preserve old score provenance | Reference epoch check |
| I11 | Replay is deterministic for recorded inputs | Pinned reducer + event order; no external calls during replay | Design only |
| I12 | Missing evidence stays unresolved | Abstention/gap outcome; unsupported certainty rejected | Design only |
| I13 | Cyclic computation has explicit convergence contracts | Cap iterations; reject nonconvergence | Design only |
| I14 | Independent evidence is not duplicated lineage | Trace acquisition lineage; reject double-counting | Design only |
| I15 | Study independence and frozen criteria survive development | Immutable hashes; no answer leakage between arms | Import integrity check |
| I16 | Shared-run work cannot exceed authorized access | Capability-scoped tools, isolated execution | Design only |
| I17 | Failure accounting includes every attempt | Retry/timeouts/unknown usage retained in run denominator | Design only |
| I18 | No commit can expose a partially written update | Transaction includes writes, receipt, event and outbox | In-memory update only; durable gate pending |
| I19 | Scientific validity is scoped | Distinguish numeric fixture, symbolic identity, formal proof and empirical evidence | Documentation; adapter pending |
| I20 | Search/selection policy is versioned and budgeted | Include controller costs; reproducible tie breaks | Design only |

## Conflict rules

Disjoint writes can still conflict through reads. Check both. Two numerical answers matching within tolerance do not permit automatic merging of incompatible assumptions. Overlapping scientific conclusions enter reconciliation; scheduling decisions may be serialized, but a lock winner is not a truth winner. Preserve both branches if neither can be excluded.

For probabilistic updates, reject repeated use of the same observation as new independent data. For new resources, an old source rediscovered through another URL is not automatically a new observation. Content and acquisition lineage are distinct identifiers.

## Failure injection acceptance

Before any distributed scientific claim, inject duplicate delivery, key collision, stale return, owner loss, lease expiry during verification, budget contention, unknown provider usage, conflicting writes, predicate phantom, crash before/after commit, missing artifact, verifier timeout, wrong verifier epoch, outbox redelivery, and dependency retraction. Target: zero invalid accepted commits and zero unexplained missing tasks. These are targets; no distributed pass is claimed here.
