# Asynchronous orchestration: development and science

## A. Agents developing this repository

This is distinct from scientific workers at runtime. Git coordinates source integration; it is not the runtime task queue or shared knowledge store.

Use a coordinator/integrator, contract owner, and bounded coding lanes. A person or agent can fill several roles sequentially. The initial lane allocation is in `work_items/BACKLOG.md`. Workers receive an issue contract, base commit, owned paths, dependencies, acceptance criteria and budget.

```bash
git worktree add ../loop-W01 -b agent/W01-state-store main
# Run from the new worktree after the integrator assigns W01.
```

For completion: commit the bounded change and open a draft PR on the chosen remote, or submit a local branch packet. Include dev log and evidence. The integrator tests the merge candidate against current main and merges one change at a time. Two agents must not simultaneously own contract or shared configuration files. If two changes depend on one API revision, merge the API contract first, then rebase consumers. Do not ask every agent to reread every chat.

### Remote bootstrap

No remote is selected in this package. After choosing one, attach its actual URL with `git remote add origin <REMOTE_URL>` and push main. Configure branch protection, CI checks, and ownership using actual account identities. Do not invent GitHub handles or claim these settings exist. Preserve a clean starter commit. A local archive remains usable without a remote.

## B. Runtime scientific workers

### Task capsule

Include run/task/attempt IDs; action; objective; unresolved obligation; relevant state slice with versions and hashes; environment; allowed tools; expected result/verification contracts; budget reservation; lease generation/expiry; epoch; output storage target; stopping conditions. Exclude the global transcript and hidden oracle labels.

Actions: DERIVE, TEST, BRANCH, RETRIEVE, REFRAME, REPAIR, RECONCILE, REVALIDATE, STOP. These are operational categories, not hard-coded scientific solution moves. An agent can propose new questions, representations, queries and operations; a new operation type needs a contract, while novel content within an existing type does not.

### Scheduler policy v0.1 (proposed, frozen before scoring)

1. Admit only valid READY tasks with enough reserved resources and eligible capabilities.
2. First handle mandatory unfulfilled verification/dependency gates.
3. Next prioritize blockers that unlock ready scientific work.
4. Rank remaining proposals by a recorded heuristic: expected decision relevance × output reliability / (estimated execution + affected recomputation cost). Inputs are ordinal rubric scores, not probabilities.
5. Apply age-based fairness within priority classes and a bounded exploration lane (initial development default: one in ten nonmandatory dispatches).
6. Tie-break by task ID; record actual candidates and chosen policy version.

Relevance/reliability rubric and cost estimator need development calibration. Do not tune on held-out outcomes. For batch admission, penalize repeated coverage of the same uncertainty and input lineage. Track interactions; never assume information gain is submodular or the objective separable without testing those assumptions.

### Resource reservation

Reserve worst-case billable input and bounded generated tokens before a model call. Use provider output limits and include any exposed reasoning allocation. Input/cached/output/reasoning accounting follows provider semantics to avoid double counting. Unknown usage remains outstanding pending reconciliation. Cannot enforce a hard token cap if the provider's charge cannot be bounded; stop that adapter or label its cap best-effort before a study.

Maintain separate resource dimensions: tokens, currency, tool calls, CPU/GPU time, wall deadline, context bytes. Reserve verification capacity as well as generation capacity. The reference ledger covers one token dimension only. Rate limit, worker count and scientific budget are independent controls.

### Failure and recovery

Retry transport/tool failures with capped attempts and jitter; never automatically retry a falsified hypothesis as if transport failed. A failed claim proposes a new branch/test. Missing resources produce a gap. Evaluator faults request evaluator review. Lease timeout fences the old owner and schedules reconciliation of external costs. Late artifacts may be retained but cannot overwrite state. Heartbeats are deterministic control traffic, not repeated LLM calls.

### Knowledge expansion and efficient intervention

When available evidence cannot meet an obligation, permit external resource search within capabilities, assess applicability, then add a candidate resource. For frozen studies, use the controlled corpus; outside-corpus access is a separately declared study condition. Do not silently change an arm's evidence access.

Use memoized calculations and local invalidation. For differentiable numerical modules with few outputs, an adjoint/sensitivity adapter may screen directions; discrete reasoning and opaque LLM calls require other methods. Sparse interaction surrogates are optional hypotheses to validate. Full replay is reserved for selected high-impact changes, failures and random audit samples. Worst-case dense coupling remains expensive.

### 100–200 identities

Benchmark a scripted queue first with chain, fan-out/join, independent and heavily shared-state workloads. Measure queued age, latency distributions, commit throughput, stale fraction, lease recovery, duplicate suppression, actual CPU, and coordination bytes. Replayed/synthetic workers do not establish live-model capability. Increase live concurrency only when fault gates pass and independent work exists; keep total budget equal in efficiency comparisons.
