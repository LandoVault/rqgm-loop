# Study plan and reporting boundaries

The two imported protocols are separate designs. Do not merge their arms or resource limits.

| Study | Arms | Planned scope | Current status |
|---|---|---|---|
| Controller/state study | A0 original; A1 fixed verification; A2 adaptive selection; A3 dependency/reuse | Oscillator, NUFFT, bounded paper formalization | Original code and several execution pins unresolved |
| Organization study | A shared sequential context; B isolated sequential; C isolated asynchronous | Five task families, 8 instances × 3 repeats × 3 arms = 360 runs | Designed, not run |
| Lifecycle equivalence | Persistent listeners vs on-demand with identical explicit state | Mock outputs and fixed event schedule | To implement |
| Infrastructure scaling | Protocol-specific scripted worker levels | Queue, leases, commits, failure injection | Not run |
| Representation/intervention extension | New amendment required | Local revision, replay economy, knowledge expansion | Design only |

Organization study caps and controller study caps differ intentionally; see the frozen texts. Complete the manifest before execution: model snapshot, sampling, exact budget semantics, seeds, development/held-out split, gate versions, task hashes, dependency locks, execution environment, baseline commit, tools and access policy. Persist an immutable preregistration hash before outcomes.

## Yang–Mills status amendment

The later user request permits a C. N. Yang paper and the prior pilot selected the Yang–Mills classical core. This resolves the choice for a known-answer integration fixture. It does not complete the frozen protocol's Lean/formalization source requirements. See amendment 0001.

## Reproducibility reporting

Never answer “100% reproducible” from six passing check groups. Report:

- Symbolic verification: 6/6 groups in the historical fixture run.
- Supplied candidate classification: expected acceptance/rejection over six supplied forms.
- Fresh independent run success: k/n runs under pinned environments and gates; absent until such runs exist.
- Paper obligation coverage: m/M only after freezing a source-to-obligation map; currently absent.
- Agent organization benefit and token efficiency: unmeasured.

Statistical units are tasks/runs, not correlated algebraic checks. Retain failures/timeouts and unknown usage. Repeated identical deterministic execution assesses execution stability, not independent rediscovery. Reproducibility across machines/tool versions and stochastic candidate generation are separate factors.

## Minimum gate order

1. Contract unit/fault tests.
2. Durable crash recovery and replay; duplicate/stale/budget stress.
3. Scientific adapters with known-answer development fixtures and seeded wrong candidates.
4. Frozen modest-concurrency organization comparison.
5. Scripted 100–200-worker infrastructure evaluation.
6. Live scaling with explicit capacity and both fixed-total-work and fixed-work-per-worker reporting.

## Outcome selection

Primary organization endpoint: verified task success within common budget. Secondary: false acceptance, appropriate abstention, tokens/cost, latency, redundant computation, and coordination. Paired comparisons by task; repeats nested in task. Use the analysis plan in each frozen protocol and record amendments before inspection. Infrastructure acceptance targets are engineering targets, not observations.

## Resource discovery test

Withhold a synthetic definition from the initial capsule but place it in an accessible controlled corpus; include distractors and an absent-definition case. Measure applicable retrieval, correct solution and justified abstention with identical access across arms. Additional tests with web search are separate because content and access can change. An agent must be allowed to invent the query; a fixture-specific hard-coded lookup would not test knowledge expansion.
