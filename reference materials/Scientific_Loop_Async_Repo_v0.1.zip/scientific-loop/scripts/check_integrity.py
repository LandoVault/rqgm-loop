"""Check immutable imports, not scientific validity."""
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'evidence/import_manifest.json').read_text())
for name, expected in manifest.items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f'FAIL: changed imported artifact: {name}')
print(f'PASS: {len(manifest)} imported artifacts match their recorded hashes')
