"""Bounded symbolic Yang--Mills reconstruction fixture, not autonomous discovery.
Run: python run_checks.py. Requires sympy==1.14.0.
The candidate grammar and verification tasks are supplied by the experimenter.
"""
import json, time, platform
from pathlib import Path
import sympy as s

started = time.perf_counter()
x, y, z, g, eps = s.symbols('x y z g eps', real=True, nonzero=True)
coords = (x,y,z)
I = s.I
T = [s.Matrix([[0,1],[1,0]])/2,
     s.Matrix([[0,-I],[I,0]])/2,
     s.diag(1,-1)/2]
A = [x*T[0]+y*T[1], x*y*T[1]+z*T[2], y*z*T[0]+x*T[2]]
psi = s.Matrix([x*y+z, x+y*z])
U = s.diag(s.exp(I*x),s.exp(-I*x))
V = U.inv()
events=[]
def simp(M): return M.applyfunc(s.simplify)
def zero(M): return simp(M)==s.zeros(*M.shape)
def comm(A,B): return A*B-B*A
def record(name, passed, **extra):
    events.append(dict(name=name, passed=bool(passed), **extra))
def D(A,mu,p): return p.diff(coords[mu])-I*g*A[mu]*p
def F(A,mu,nu,k=-1):
    return A[nu].diff(coords[mu])-A[mu].diff(coords[nu])+I*g*k*comm(A[mu],A[nu])
def dadj(mu,M): return M.diff(coords[mu])-I*g*comm(A[mu],M)

# Each proposed coefficient is verified; failed candidates remain in the log.
qchosen=None
for q in (0,1,-1):
    Ap=[simp(U*a*V+q*I/g*U.diff(c)*V) for a,c in zip(A,coords)]
    passed=all(zero(D(Ap,m,U*psi)-U*D(A,m,psi)) for m in range(3))
    record('connection candidate',passed,q=q,expected_outcome='accept' if q==-1 else 'reject')
    if passed: qchosen=q; break
assert qchosen==-1
kchosen=None
for k in (0,1,-1):
    passed=all(zero(F(Ap,m,n,k)-U*F(A,m,n,k)*V) for m,n in ((0,1),(0,2),(1,2)))
    record('curvature candidate',passed,k=k,expected_outcome='accept' if k==-1 else 'reject')
    if passed: kchosen=k; break
assert kchosen==-1

# General symbolic SU(2) commutator/operator check, arbitrary smooth fields.
Ag=[sum((s.Function(f'a{mu}{j}')(*coords)*T[j] for j in range(3)),s.zeros(2)) for mu in range(3)]
pg=s.Matrix([s.Function('p0')(*coords),s.Function('p1')(*coords)])
record('operator curvature identity, arbitrary smooth fields',
       zero(D(Ag,0,D(Ag,1,pg))-D(Ag,1,D(Ag,0,pg))+I*g*F(Ag,0,1)*pg))

# A distinct gauge axis and coordinate is a held-out fixture, not a blind paper test.
U2=s.cos(y)*s.eye(2)+2*I*s.sin(y)*T[0]
V2=s.cos(y)*s.eye(2)-2*I*s.sin(y)*T[0]
A2=[simp(U2*a*V2-I/g*U2.diff(c)*V2) for a,c in zip(A,coords)]
record('held-out fixture: local gauge covariance',all(zero(F(A2,m,n)-U2*F(A,m,n)*V2) for m,n in ((0,1),(0,2),(1,2))))
record('quadratic trace invariant',s.simplify(s.trace(F(Ap,0,1)**2)-s.trace(F(A,0,1)**2))==0)
record('Bianchi identity, polynomial fixture',zero(dadj(0,F(A,1,2))+dadj(1,F(A,2,0))+dadj(2,F(A,0,1))))
Ab=[x*y*T[2],y*z*T[2],z*x*T[2]]
record('Abelian reduction',zero(F(Ab,0,1)-(Ab[1].diff(x)-Ab[0].diff(y))))

# Check first variation before using integration by parts in the written derivation.
H=[z*T[1],x*T[0],y*T[2]]
Ae=[a+eps*h for a,h in zip(A,H)]
deltaF=F(Ae,0,1).diff(eps).subs(eps,0)
record('curvature first variation',zero(deltaF-(dadj(0,H[1])-dadj(1,H[0]))))

checks=[e for e in events if 'expected_outcome' not in e]
assert all(e['passed'] for e in checks)
out={'scope':'classical core; bounded, author-supplied candidate grammar',
     'python':platform.python_version(),'sympy':s.__version__,
     'elapsed_seconds':time.perf_counter()-started,
     'candidate_evaluations':6,'rejected_candidates':4,
     'verification_groups':len(checks),'verification_groups_passed':sum(e['passed'] for e in checks),
     'token_usage':None,'token_note':'No model API usage accounting available; no token-efficiency claim.',
     'events':events,
     'limitations':['Not full paper replication','Not Lean formalization','No baseline comparison',
                    'No autonomous resource discovery test','No 100--200 live-agent test',
                    'Finite fixtures do not prove universal gauge covariance; see analytic argument.']}
Path(__file__).with_name('results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
