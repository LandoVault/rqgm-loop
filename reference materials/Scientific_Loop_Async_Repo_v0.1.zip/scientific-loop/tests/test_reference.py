import sys
from pathlib import Path
import unittest
from dataclasses import replace
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from scientific_loop.reference import Kernel, Patch, Rejected, TokenLedger

class CommitContracts(unittest.TestCase):
    def setUp(self):
        self.k = Kernel()
        self.k.entities['a'] = (1, {'value': 1})
        self.k.lease('t', 'worker', 0, 10, ['symbolic', 'scope'])
        self.p = Patch('r', 't', 'worker', 1, 1, {'a': 1}, {'b': 0}, {'b': {'v': 2}})
        self.verdict = {'symbolic': 'PASS', 'scope': 'PASS'}
    def test_commit_and_duplicate(self):
        receipt = self.k.commit(self.p, self.verdict, 1)
        self.k.epoch = 2
        self.assertEqual(receipt, self.k.commit(self.p, {}, 100))
        self.assertEqual(self.k.entities['b'][0], 1)
    def test_same_key_different_payload_rejected(self):
        self.k.commit(self.p, self.verdict, 1)
        with self.assertRaisesRegex(Rejected, 'IDENTITY_CONFLICT'):
            self.k.commit(replace(self.p, writes={'b': 99}), self.verdict, 2)
    def test_stale_read_rejected_without_partial_write(self):
        self.k.entities['a'] = (2, {})
        with self.assertRaisesRegex(Rejected, 'STALE'):
            self.k.commit(self.p, self.verdict, 1)
        self.assertNotIn('b', self.k.entities)
    def test_lost_write_rejected(self):
        self.k.entities['b'] = (1, 'other')
        with self.assertRaisesRegex(Rejected, 'STALE'):
            self.k.commit(self.p, self.verdict, 1)
    def test_expired_lease(self):
        with self.assertRaisesRegex(Rejected, 'EXPIRED'):
            self.k.commit(self.p, self.verdict, 10)
    def test_fenced_old_worker(self):
        self.k.lease('t', 'new', 10, 10, ['scope', 'symbolic'])
        with self.assertRaisesRegex(Rejected, 'FENCED'):
            self.k.commit(self.p, self.verdict, 11)
    def test_active_lease_cannot_be_stolen(self):
        with self.assertRaisesRegex(Rejected, 'ALREADY_LEASED'):
            self.k.lease('t', 'new', 2, 10, ['scope'])
    def test_new_epoch(self):
        self.k.epoch = 2
        with self.assertRaisesRegex(Rejected, 'EPOCH_CHANGED'):
            self.k.commit(self.p, self.verdict, 1)
    def test_missing_unknown_failed_and_error_verdicts(self):
        for value in [None, 'UNKNOWN', 'FAIL', 'ERROR']:
            with self.subTest(value=value), self.assertRaisesRegex(Rejected, 'GATE_FAILED'):
                self.k.commit(self.p, {'symbolic': 'PASS', 'scope': value}, 1)
    def test_all_writes_need_expectations(self):
        with self.assertRaisesRegex(Rejected, 'WRITE_SET_MISMATCH'):
            self.k.commit(replace(self.p, writes={'b': 2, 'c': 3}), self.verdict, 1)
    def test_disjoint_updates_share_unchanged_read(self):
        self.k.lease('t2', 'other', 0, 10, ['scope'])
        other = Patch('r2', 't2', 'other', 1, 1, {'a': 1}, {'c': 0}, {'c': 3})
        self.k.commit(self.p, self.verdict, 1)
        self.k.commit(other, {'scope': 'PASS'}, 2)
        self.assertEqual(self.k.entities['c'], (1, 3))
    def test_second_result_cannot_complete_task_again(self):
        self.k.commit(self.p, self.verdict, 1)
        with self.assertRaisesRegex(Rejected, 'TASK_COMPLETED'):
            self.k.commit(replace(self.p, result_id='r2'), self.verdict, 2)
    def test_absence_read_detects_new_entity(self):
        p = replace(self.p, reads={'new': 0})
        self.k.entities['new'] = (1, 0)
        with self.assertRaisesRegex(Rejected, 'STALE'):
            self.k.commit(p, self.verdict, 1)
    def test_input_payload_not_aliased(self):
        self.k.commit(self.p, self.verdict, 1)
        self.p.writes['b']['v'] = 999
        self.assertEqual(self.k.entities['b'][1]['v'], 2)

class Budgets(unittest.TestCase):
    def test_pending_reservations_count(self):
        b = TokenLedger(100)
        b.reserve('a', 60)
        with self.assertRaisesRegex(Rejected, 'BUDGET_DENIED'):
            b.reserve('b', 50)
        b.settle('a', 30)
        b.reserve('b', 50)
        self.assertEqual(b.spent + sum(b.pending.values()), 80)
    def test_unknown_usage_remains_reserved(self):
        b = TokenLedger(100); b.reserve('a', 100); b.settle('a', None)
        with self.assertRaisesRegex(Rejected, 'BUDGET_DENIED'):
            b.reserve('b', 1)
    def test_settlement_idempotency_and_conflict(self):
        b = TokenLedger(100); b.reserve('a', 50); b.settle('a', 30); b.settle('a', 30)
        self.assertEqual(b.spent, 30)
        with self.assertRaisesRegex(Rejected, 'USAGE_CONFLICT'):
            b.settle('a', 20)
    def test_provider_bound_breach_records_cost_and_halts(self):
        b = TokenLedger(100); b.reserve('a', 50)
        with self.assertRaisesRegex(Rejected, 'PROVIDER_BOUND_BREACH'):
            b.settle('a', 60)
        self.assertEqual(b.spent, 60)
        with self.assertRaisesRegex(Rejected, 'BUDGET_DENIED'):
            b.reserve('b', 1)

if __name__ == '__main__':
    unittest.main()
