# Amendment 0001 — handoff scope, not a scored-run amendment

Date: 2026-09-25 America/New_York. Status: engineering design addition. No comparative scoring outcomes inspected or new study runs authorized by this amendment.

The prior conversation now identifies a Yang–Mills classical-core reconstruction as the paper integration fixture. Imported protocols remain byte-for-byte unchanged. Formal proof source/toolchain and original executable remain unresolved. The new architecture, state, knowledge-gap, verifier and orchestration documents specify an implementation target. Their reference kernel is not the original RQGM implementation and must not be used under that label.

No arm, budget, outcome, sample size or frozen verification threshold is altered here. Future decisions that alter them require a separate numbered amendment before scoring.
