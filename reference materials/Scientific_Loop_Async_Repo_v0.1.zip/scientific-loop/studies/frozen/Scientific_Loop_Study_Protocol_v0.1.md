# Scientific loop study — protocol v0.1

Date: 2026-09-25

Status: design snapshot only. No study runs, optimization epochs, timing measurements, or Lean compilation have been performed. The comparison and reporting rules below are fixed for this version. Execution remains blocked on completing the source manifest; this is not a fully executable preregistration yet. Changes require a numbered amendment recorded before outcome inspection.

## 1. Question and scope

Does explicit scientific action selection and dependency-aware state management add value to the user's existing RQGM/SRM design, at matched resources? Separately, can the execution infrastructure support 100–200 workers without losing correctness or allowing coordination costs to dominate?

Do not equate better task scores with autonomous scientific discovery, known-result reconstruction with novelty, or a successful simulator with a working live agent team.

The user requested design freeze first and experiments later. This document does not authorize or launch an experiment.

## 2. Recovered original architecture

The current retrieved July 3 file `02_architecture.md` describes an SRM/MVL system with a Python controller, proposal/response handshakes, deterministic admission gates, independent cross-checks, serialized random state, an archive, fresh-context LLM roles, and explicit budgets. Its central principle is that code enforces gates and LLMs provide judgment inputs. These are baseline capabilities, not new contributions of the proposed extension.

The file is a summary, not executable source. It identifies `serendip_loop/controller.py`, `world.py`, `setup_seal.py`, and `scorer.py`, and says the canonical specifications prevail over the summary. It describes some MVL v2 changes as TO-BE-BUILT. Their implementation must not be inferred.

The September conversation separately proposed Strategic and Development loops governed by a Central Meta-Evaluator. Do not collapse this proposal, the July implementation, and the published RQGM algorithm into one claimed implemented baseline.

No source repository or executable baseline has been retrieved. If it cannot be obtained, a proxy may be run only under an explicit proxy label, and cannot establish improvement over the user's original system. No existing frozen SRM/MVL study, seal, or protocol is modified by this new study.

## 3. Arms and attribution

| Arm | Definition | Purpose |
|---|---|---|
| A0 | Original implementation, pinned commit and configuration | Primary baseline; unavailable until source manifest is complete |
| A1 | A0 plus a strong fixed schedule covering the full scientific verification checklist | Tests whether improved coverage alone explains gains |
| A2 | A1 with adaptive action selection; same tools, tests, model, and budget | Isolates adaptive scheduling |
| A3 | A2 plus explicit hypothesis dependencies, selective invalidation, and reusable result cache | Tests state management and reuse |

If A0 already implements an extension, do not add it twice: record the mapping and amend the arm definitions before any scoring runs. Preserve the original evaluator-change policy identically across arms. A later experiment may ablate evaluator evolution, but this first comparison must not confound it with scheduling.

Use the same model snapshot, sampling configuration, initial repository, available evidence, test menu, and tool permissions within paired runs. No adaptive arm receives hidden tests or oracle labels that other arms lack. Controller actions and rejected candidates consume budget. All arms retain mandatory final verification.

## 4. Scientific workloads

### P1. Forced damped oscillator

Reconstruct and implement the solution of

`m x'' + c x' + k x = F cos(omega t)`, with `m > 0`, `k > 0`, `c >= 0`, and specified initial displacement and velocity.

Required chain: normalize the equation; derive a particular solution; add the homogeneous solution; enforce initial conditions; handle damping regimes and resonance; implement evaluation; verify independently.

For the nonresonant complex particular solution use `F exp(i omega t)/(k - m omega^2 + i c omega)`. Its real part is not by itself the initial-value solution. The zero-damping resonant case must use its limiting/resonant solution, not divide by zero. Critical damping must not be evaluated with an unprotected repeated-root formula.

Verification covers initial conditions, differential-equation residuals, independently integrated trajectories, zero-force limits, under/critical/overdamping, and undamped resonance. Use double precision and scale-aware residuals. Reference integrator tolerances and numerical acceptance thresholds must be pinned in the source manifest and sanity-checked before the scoring set is created.

Difficulty includes seeded missing-transient, sign, and singular-limit errors. Mutation locations are withheld from workers. These are engineering tests of diagnosis and reconstruction, not unseen physics discovery.

### P2. Nonuniform FFT

Default scope: one-dimensional type-1 transform with nonuniform source locations and uniform integer Fourier modes:

`f_k = sum_j c_j exp(-i k x_j)`.

The negative sign, lack of normalization, mode ordering, and periodic coordinate convention must be explicit. A type-1 transform is not generally an inverse reconstruction from irregular samples. If both source positions and requested frequencies are nonuniform, that is a separate type-3 extension, not silently substituted into this workload.

Required chain: define the finite sum; explain why a plain FFT does not directly apply; derive periodic spreading to an oversampled grid; apply FFT; derive kernel deconvolution and mode extraction; account for truncation and aliasing; implement and test.

Use a transparent Gaussian-gridding prototype and direct complex summation as the small-case oracle. A production NUFFT library may be a second independent reference after version pinning. Success requires error checks on all specified modes, not only the zero mode. Test random, clustered, near-boundary, coincident, and uniform locations; complex strengths; cancellation; and varying bandwidths. Record both relative L2 error and error normalized by `sum(abs(c_j))` to avoid unstable relative scores near cancellation. Claim speedup only after a size sweep and repeated wall-clock measurements.

### P3. Multi-step paper reconstruction with formal verification

Pending exact author/paper and intended formalization source. The spoken author name is unresolved. Lee and Yang's 1956 parity paper is a candidate only; Yang–Mills is a different candidate. Do not label either as user-selected.

“First Derivation Lab” / CodexBase source was not identified by history or file retrieval. PhysLean/Physlib was located publicly but has not been established as the user's intended source. No code has been borrowed.

Once identified, select a bounded central chain of 8–12 obligations rather than claiming full-paper reproduction. For each obligation record the informal statement, formal statement, premises, source location, dependencies, proof artifact, and empirical assumptions. Evaluate logical closure and statement fidelity separately. Kernel acceptance does not verify that a formal statement captures the physical claim or that its empirical premises are true.

Require pinned repository commit, dependency lock, Lean toolchain, license, build command, and successful reference build. Audit `sorry`/`admit`, added axioms, and theorem dependencies. Standard logical axioms are not automatically defects; report the actual trusted base. Lean/lake were not found in this execution environment during preparation. Uncompiled proof sketches must not be counted as formal successes.

## 5. Controller contract

Each action is one of DERIVE, TEST, BRANCH, REPAIR, or STOP/DEFER. Its request names the unresolved obligation, relevant dependency versions, proposed artifact, expected evidence, and cost ceiling. Responses are structured; malformed output is logged and handled by a deterministic fallback, consistent with the recovered baseline philosophy.

The initial adaptive policy is a frozen, inspectable rubric: prioritize unresolved mandatory gates; then actions expected to discriminate surviving hypotheses per estimated cost; then bounded exploration. Predicted information value is a heuristic, not a calibrated probability. Publish the exact scoring and tie-breaking code before execution. Do not tune it using held-out outcomes.

Keep raw observations, candidate claims, and evaluator judgments separate. A new evaluator invalidates affected selection scores; observations and historical records remain. A changed premise marks dependent claims stale until rechecked. Alternative assumption branches remain distinct; conflicting scientific claims are not merged by majority vote.

## 6. Architecture for 100–200 workers

Design target: a durable registry and scheduler supporting 200 concurrently active worker identities. This is not a claim about current conversational tool capacity or available provider quota. This session exposes at most seven agent slots, so a 200-live-agent test requires a separate execution environment.

Use a deterministic dispatcher, durable task queue, bounded worker pools, and a content-addressed artifact store. Partition tasks by domain/branch, with atomic acceptance per affected record. Use advisory LLM planning only for decisions requiring it. Routine routing, budgets, leases, schema checks, cache lookup, and version checks are code.

Workers receive compact task capsules and retrieve only needed artifacts. They do not inherit the global transcript. Return evidence references, a concise result, and machine-readable changes. Cache proofs and numerical results by code/data/assumption/toolchain versions. A dependency change invalidates only affected cache entries.

Use at-least-once delivery with idempotent result acceptance, leases, fencing tokens, retry limits, and backpressure. Do not claim exactly-once external execution. Duplicate completions cannot create duplicate findings. A late worker cannot overwrite newer state. Independent branches proceed asynchronously; conflicting writes, necessary dependency joins, and evaluator epoch changes have explicit commit rules.

At an evaluator boundary stop issuing work under the old version; tag in-flight returns with their original version. Retain them for provenance but exclude old scores from the new ranking unless re-evaluated. Never silently relabel an old judgment as new.

Avoid all-to-all messaging: 200 workers permit 39,800 directed pairwise links. This is a potential topology size, not a measured message count. Shared targeted retrieval and queue dispatch should keep control traffic tied to actual tasks and dependency changes. Tree depth, coordinator overhead, and central commit contention still require measurement.

## 7. Resources and token accounting

Initial design ceiling per scientific run: 100 controller actions, 100,000 aggregate uncached input tokens, 25,000 aggregate generated tokens including reasoning when reported, and 60 minutes wall time. Stop at the first exhausted ceiling; unfinished work is a scored outcome. These are caps, not a request to consume the budget. Model-specific accounting gaps must be reported, not estimated as zero.

Record input, cached input, output, reasoning tokens where exposed, model requests, retries, tool CPU/GPU seconds, verifier time, wall time, and bytes of context transferred. Count planners, reviewers, repair, summarization, and evaluator selection. Report preparation/development expenditure separately from per-run expenditure. Report token and compute Pareto curves rather than hiding tradeoffs in one weighted score.

Primary scientific endpoint: fraction of preregistered obligations independently verified within the resource cap. Report at run level; do not treat dependent lemmas as independent trials. Secondary endpoints: fully completed cases, invalid final claims, token cost per verified obligation, time to first valid result, cache benefit, duplicated work, and human interventions. A run with zero verified obligations has undefined cost per success and remains a failure in aggregate reporting.

## 8. Stages and analysis

1. Complete and hash source manifest; map actual baseline features to arms.
2. Infrastructure-only sanity tests with scripted worker responses. No model-quality claims.
3. Freeze task instances, split definitions, numerical tolerances, formal obligations, and controller code. Setup examples are excluded from scoring.
4. Scientific comparison at modest concurrency: 20 paired run seeds per arm per admitted task family; identical caps and randomized run order. Report paired differences and 95% paired bootstrap intervals, plus all failures. This is an exploratory proof of concept, not a powered universal superiority claim. If cost prevents the fixed sample, report the shortfall without outcome-dependent extension.
5. Scheduler replay/load test at 1, 8, 32, 100, and 200 scripted workers, at least 10,000 tasks per level with recorded task-duration distribution. Test chain, fork/join, independent, and shared-state-heavy graphs. Inject duplicate delivery, timeout, worker loss, stale return, restart, and evaluator-boundary events.
6. Only after infrastructure correctness, run live-worker scaling on provisioned capacity. Measure both fixed-total-work strong scaling and fixed-work-per-worker weak scaling. The latter increases aggregate cost and must not be called an efficiency gain without normalization.

Suggested engineering acceptance targets, fixed as targets rather than observations: zero accepted stale/conflicting writes or duplicate findings in the fault suite; no unexplained task loss; control-plane overhead under 10% of total execution time in the long-task workload. Failure of a target is reported rather than hidden by changing workloads. Scheduler replay success does not establish scientific or token-efficiency gains.

Conclude that an extension is promising only if it improves verified outcomes without more false acceptance at matched resources, or achieves comparable outcomes at lower measured cost. If A1 matches A2/A3, attribute improvement to verification coverage. If A3 helps only after restart or dependency changes, report that restricted benefit. Never report this as evidence for unbounded recursive self-improvement.

## 9. Required source manifest before execution

- Original controller, tools, and scoring repository: URL/local transfer and commit; not yet retrieved.
- Intended First Derivation Lab source: exact artifact/repository; unresolved.
- Paper title/DOI and selected obligation chain: unresolved.
- Model snapshot, token-reporting support, provider quota, worker environment: unpinned.
- Lean toolchain, dependencies, reference build, license: unpinned/unverified.
- Test generators, splits, numerical thresholds, controller priority code, and frozen hashes: to be completed before outcome inspection.

The general protocol can be reviewed now. P3 cannot be finalized by guessing its source. P1/P2 definitions remain useful independently; original-system comparisons await the actual baseline.

## References and provenance

- User architecture: `02_architecture.md`, July 3, 2026, retrieved and read in this session. Summary only; no source execution.
- RQGM: https://arxiv.org/abs/2606.26294 ; author algorithm explanation: https://mlsys.cst.cam.ac.uk/2026/07/19/who-evaluates-the-evaluator.html
- NUFFT definitions: https://finufft.readthedocs.io/en/latest/math.html
- Gaussian gridding: Greengard and Lee, SIAM Review 46, 443–454 (2004), https://doi.org/10.1137/S003614450343200X
- Candidate paper, not selected: Lee and Yang, Physical Review 104, 254 (1956), https://doi.org/10.1103/PhysRev.104.254
- Possible alternative formal library, not identified as intended source: https://physlean.com/ (redirects to Physlib).

## Amendment log

v0.1: initial design snapshot; incorporates freeze-first instruction and 200-worker target. No experiments executed. Future source-resolution and parameter-lock amendments must precede scoring.
