# Implementation backlog

All items are unassigned and planned. No background agents are running. Integrator assigns ownership serially until an atomic issue service exists.

| ID | Lane / owned paths | Depends on | Deliverable and acceptance |
|---|---|---|---|
| W00 | Contract owner: specs/, docs/STATE_MACHINE.md | — | Resolve canonical JSON and certificate/predicate guards; examples validate; no scientific arm change |
| W01 | State: src/scientific_loop/store/, tests/store/ | W00 | Durable entities/events/receipts/outbox transaction; crash before/after commit preserves invariants I03–05/I18 |
| W02 | Verifier: src/scientific_loop/verifiers/, tests/verifiers/ | W00 | Attestation binding, four verdict classes, scientific scope; forged/mismatched attestation rejected |
| W03 | Queue/budgets: src/scientific_loop/runtime/, tests/runtime/ | W00,W01 | Leases/fencing/reconciliation/backpressure; budget contention and unknown usage cannot cause silent overspend |
| W04 | Knowledge: src/scientific_loop/knowledge/, tests/knowledge/ | W00; mocks allowed | Gap/retrieval/applicability/reframe flow; synthetic corpus absent-data test abstains |
| W05 | Domain adapters: src/scientific_loop/domains/, tests/domains/ | W02 | Yang–Mills adapter preserves fixture; oscillator/NUFFT gates pinned on development set |
| W06 | Providers: src/scientific_loop/providers/, tests/providers/ | W00,W03 | Mock-first capsule/usage interface; live adapter bounded outputs, no secret logs |
| W07 | Study: studies/manifests/, scripts/study/, tests/study/ | W01–06 | A/B/C implementation with equal information/budgets, frozen split hashes, accounting and leakage audit |
| W08 | Load/fault: scripts/load/, tests/faults/ | W01–03 | Deterministic faults at 100–200 identities; no invalid acceptance, duplicate findings or unexplained task loss |
| W09 | Formalization: src/scientific_loop/formal/ | Source resolution,W02 | Intended source/license/toolchain recorded; successful build and axiom/statement audit |
| W10 | Baseline importer: studies/baseline/ | Original source available | Pinned original commit/features mapped without invented capabilities; proxy explicitly separate |

W01 and W02 can proceed in parallel after W00; W04 can use mocks. Shared packaging/config changes belong to the integrator. Avoid circular dependencies by committing contracts and test doubles first.

## Definition of ready

Known base commit, owned paths, inputs, invariant IDs, acceptance tests, budget, no unresolved interface ownership. A blocked dependency is not permission to silently invent its behavior.

## Definition of done

Reviewed code, merged-tree tests, usage/limitations, dev log, migration/rollback, and explicit integration status. A pull request existing is not completion; a green mock test is not a passed scientific study.
