## Problem and resulting behavior

Work item:
Base commit:
Owned paths:

## Contracts and evidence

Invariant IDs:
Exact checks and results:
Dev log:
Study/protocol impact (or none):

## Integration

Dependencies:
Untested risks:
Migration/rollback:
