# Scientific Loop — asynchronous research substrate

Version 0.1.0 • Prepared September 25, 2026 (America/New_York)

A repository starter for persistent scientific state, verified revisions, resource discovery, and budgeted asynchronous work. It preserves the proposed Strategic / Development / Meta-Evaluator loops, with a scientific state and scheduling layer beneath them.

**Status:** architecture and contracts are specified; a small in-memory contract reference and tests are included. A durable distributed scheduler, model adapters, API service, and 100–200-agent runtime are **not implemented**. No comparative scientific study has run. This is a local Git repository with no remote configured.

## Start here

1. Read [HANDOFF.md](HANDOFF.md) and [AGENTS.md](AGENTS.md).
2. Read [architecture](docs/ARCHITECTURE.md), [state machine](docs/STATE_MACHINE.md), [invariants](docs/INVARIANTS.md), and [verifier](docs/VERIFIER.md).
3. Use [contracts](specs/CONTRACTS.md), [orchestration](docs/ORCHESTRATION.md), and [implementation backlog](work_items/BACKLOG.md) to implement one bounded work item.
4. Follow [study design](docs/STUDY_DESIGN.md); preserve the two imported frozen protocols.
5. Record factual changes and evidence in a new [development log](dev_logs/TEMPLATE.md).

See [BOOTSTRAP.md](BOOTSTRAP.md) to clone the included Git bundle and attach a shared remote.

## Local checks

Python 3.11+ is the target for the contract reference; no third-party dependency is needed for its tests.

```bash
python -m unittest discover -s tests -v
python scripts/check_integrity.py
```

The imported Yang–Mills fixture separately requires `sympy==1.14.0`. Preserve the imported results: run a copy in a new directory, as described in `docs/VERIFIER.md`. Do not treat its six passing verification groups as six independent replication experiments.

## Repository map

| Path | Purpose |
|---|---|
| `docs/` | Architecture, lifecycle, invariants, verification, orchestration, studies |
| `specs/` | Data contracts and example candidate patch |
| `src/scientific_loop/` | In-memory acceptance and budget reference, not a service |
| `tests/` | Contract failure cases and reference behavior |
| `scripts/` | Imported-artifact integrity check |
| `fixtures/yang_mills/` | Unmodified historical code, report and result |
| `studies/frozen/` | Unmodified prior design snapshots |
| `studies/amendments/` | Explicit additions; no retroactive protocol edits |
| `work_items/` | Parallelizable backlog and ownership boundaries |
| `dev_logs/` | Append-only development evidence and handoffs |
| `evidence/` | Hash manifest and checks performed for this package |

No deployment, account connection, external communication, live model invocation, or remote push is performed by this starter.
