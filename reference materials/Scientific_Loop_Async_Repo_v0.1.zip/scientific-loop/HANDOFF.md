# Project handoff

## Goal and scientific question

Build an efficient, inspectable substrate that chooses useful scientific work, revises claims when evidence changes, and can discover relevant resources outside its current hypotheses. Determine when isolated contexts and asynchronous scheduling improve verified results at matched budgets. Scale the infrastructure toward 100–200 worker identities without assuming all workers must invoke a model simultaneously.

The foundational object is a **persistent scientific state with verified transformations**. Loop depth and agent headcount are implementation choices. Success is independently verified work under explicit resource limits, with false acceptance and missing evidence visible.

## Recovered evidence

| Item | Status and consequence |
|---|---|
| Scientific_Loop_Study_Protocol_v0.1.md | Read current authoritative content; local copy matches that content and is frozen in this package |
| Agent_Organization_Study_v0.1.md | Read from the exact prior local path; copied unchanged |
| Yang–Mills run_checks.py, results.json, Study_Report.md | Read from prior local path and copied unchanged; supplied grammar, two selection loops, six extra symbolic check groups |
| Original RQGM/SRM/MVL executable | Not recovered; cannot claim this is a modification of its source or measured improvement over it |
| First Derivation Lab / CodexBase / Lean artifact | No exact title match recovered; remains unresolved; do not substitute another library silently |
| Original Yang–Mills PDF | Prior local artifact exists; not repackaged; source citation and interpretation remain in imported report |
| Earlier literature claims | Preserved as historical protocol text; not rechecked for this engineering handoff |

The imported pilot reports six of six symbolic verification groups passing, four rejected and two accepted supplied candidates, and about 33.38 seconds in its historical run. Token usage is unknown. This is a check pass fraction, **not a reproducibility rate**, a full-paper completion percentage, or autonomous discovery. Three coordinates are algebraic fixtures, not a 3D physical field simulation. A fresh run, if performed, is logged separately.

## Decisions now specified

- Shared typed claims/evidence network; execution dependencies and conceptual relations are distinct.
- On-demand role contexts; listeners may persist without model inference.
- Deterministic scheduling, lease ownership, budget admission, and commit validation.
- At-least-once task delivery; idempotent acceptance; fencing for expired workers.
- Immutable observations and event history; revision of claims and scores through new records.
- Conditional proof support and observation evidence are not interchangeable.
- Knowledge-gap operations can retrieve new resources or propose a new representation.
- Incremental invalidation is the default; expensive intervention replay is selective.
- Separate frozen experiments for architecture changes and agent organization.
- Worktree-based asynchronous repository development; shared-state commits occur only through the runtime coordinator, not Git files edited by all workers.

## Implementation truth

The included reference kernel demonstrates a narrow subset: lease generation checks, read-version checks, write expectations, mandatory verification IDs, verifier epoch, result identity, and budget reservation. It is single-process and in-memory. It is not secure against malicious clients, does not verify proof artifacts, and is not crash durable. Its tests demonstrate contract behavior only. Production work starts with W01–W03.

## Immediate sequence

1. Assign a contract owner and integrator. Read the invariant IDs before editing.
2. Implement W01 transactional state/lease/outbox storage and W02 verifier harness against the specified interfaces.
3. Implement W03 durable queue and budget ledger after contract agreement; W04 knowledge-gap adapter can proceed on mocks.
4. Import the original executable and intended formalization source when available; record hashes, license, versions, and actual features.
5. Complete study manifests and development-only calibration; freeze thresholds before scored execution.
6. Run scripted fault and replay tests before live model studies; run modest concurrency before 100–200-worker load tests.

Do not block infrastructure work on absent original code. Label reconstructed baselines as proxies, and keep them out of claims about superiority to the original.

## Open decisions with defaults

| Decision | Default / condition for changing |
|---|---|
| Durable MVP store | Transactional relational database plus immutable blob storage; local single-process prototype may use SQLite |
| Queue | Database task table + transactional outbox first; separate broker only if measured need |
| Live concurrency | Start at four, admit only ready work with reserved resources |
| Model/provider | Unselected; pin before studies; mock adapters first |
| Representation | Typed records and dependency adjacency; embeddings optional retrieval index |
| Numerical tolerances / Lean | Unpinned; affected workloads cannot claim scored success |
| Remote repository | None selected; owner can attach an existing or new private remote |

## Acceptance for next handoff

Supply commit IDs, changed paths, invariant IDs covered, exact commands/results, known unimplemented contracts, remaining budget/usage gaps, and one executable next step. A proposal, a test plan, and a passing experiment must have different labels.
