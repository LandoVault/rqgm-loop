# Contracts v0.1

Normative production design. The included Python reference is intentionally narrower and does not implement these APIs as network endpoints.

## Record conventions

UTF-8 canonical JSON; identifiers opaque; timestamps UTC; hashes `sha256:<hex>`; explicit schema_version; integer versions never reused. Canonical digest excludes mutable receipt metadata but includes every candidate field, including read/write sets and artifact hashes. Pin the canonicalization algorithm. Do not rely on language-dependent map iteration.

| Record | Required fields |
|---|---|
| EntityRevision | entity_id, version, kind, payload_hash, environment_id, prior_revision, created_event |
| Evidence | evidence_id, artifact_hash, source_locator, acquisition_time, acquisition_lineage_id, scope, corrections |
| Dependency | dependent_id/version, prerequisite_id/version, relation_type, environment_id, certificate_id |
| Task | run_id, task_id, action, obligation_ids, environment_id, status, prerequisites, policy_version, priority_inputs, max_attempts |
| Lease | task_id, attempt_id, owner_id, fencing_token, server_expires_at, reservation_id |
| CandidatePatch | schema_version, run_id, task_id, attempt_id, result_id, owner_id, fencing_token, epoch, read_set, write_set, artifact_refs, environment_hash, usage_ref |
| ReadGuard | entity_id, expected_payload_version, expected_certificate_version; collection_version for predicate reads |
| WriteIntent | entity_id, expected_version (0 for absent), new_payload_hash; operation restricted by entity kind |
| VerificationRecord | candidate_digest, verifier identity/version/code_hash, epoch, environment_hash, obligation_verdicts, artifact hashes, command, usage |
| Event | sequence, event_id, run_id, type, schema_version, payload_hash, causation_id, correlation_id, recorded_at |
| Usage | provider request_id, reservation_id, input/cached/output/reasoning values, charge semantics, tools, CPU/GPU, status known/unknown |

Human-readable explanation is optional supporting material; it cannot replace these fields.

## Coordinator operations

| Operation | Inputs | Result / conflicts |
|---|---|---|
| claim_task | task_id, owner, capability set | lease + capsule or NOT_READY/BUDGET_DENIED |
| heartbeat | attempt, fencing token | extended expiry or FENCED |
| propose | candidate patch, artifact refs | immutable candidate ID; same-key mismatch → IDENTITY_CONFLICT |
| verify | candidate ID, verifier contract | signed/authenticated verification record or UNKNOWN/ERROR |
| commit | candidate ID, verification refs, idempotency key | receipt or STALE/FENCED/EXPIRED/GATE_FAILED/EPOCH_CHANGED |
| report_gap | obligation, gap class, proposed query/reframe | gap record and optional scheduled task |
| settle_usage | reservation, provider usage | atomic ledger update; unknown retained |
| advance_epoch | successor hash, validation refs | explicit boundary event; never direct worker call |

## Read/write conflict example

Worker X reads A:v3 and writes B expecting v2. Worker Y changes A to v4 while X computes. X cannot commit even though Y did not write B. Revalidate against A:v4. If a worker searches “all supporting evidence” and new evidence is inserted, record a collection/predicate guard; entity guards alone miss that phantom.

## Storage transaction requirements

Unique keys: (run_id,result_id), (run_id,event_id), task attempt ID, provider request ID, artifact hash. Foreign keys ensure referenced revisions exist. Transaction isolation or explicit row/collection locks must prevent write skew. Durable task transition and outbox append share the transaction. Exact duplicate commit returns original receipt even if current epoch later changes; it does not create a new current acceptance.

## Reference-only simplifications

Python `Kernel` uses integer payload versions and a trusted in-process verdict dictionary; it lacks certificate guards, predicate guards, dependency invalidation, durable event log, authenticated verifiers, multiple processes, and artifact storage. Its budget ledger models bounded token reservations only. It is an executable discussion aid and test seed, not a deployable coordinator.
